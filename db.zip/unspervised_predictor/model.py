import re
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
import nltk
import pickle

class UnsupervisedNewsClassifier:
    def __init__(self, vectorizer_path, kmeans_path, isolation_forest_path, news_article):
        self.tfidf_vectorizer = None
        self.kmeans = None
        self.isolation_forest = None
        self.news_article = news_article
        self.cleaned_input = None

        self.load_models(vectorizer_path, kmeans_path, isolation_forest_path)
        self.preprocess_input()

    def load_models(self, vectorizer_path, kmeans_path, isolation_forest_path):
        with open(vectorizer_path, 'rb') as file:
            self.tfidf_vectorizer = pickle.load(file)

        with open(kmeans_path, 'rb') as file:
            self.kmeans = pickle.load(file)

        with open(isolation_forest_path, 'rb') as file:
            self.isolation_forest = pickle.load(file)

        return self.tfidf_vectorizer, self.kmeans, self.isolation_forest

    def preprocess_input(self):
        self.cleaned_input = re.sub(r'[^\w\s]', '', self.news_article.lower())
        self.tokenized_input = [word for word in word_tokenize(self.cleaned_input) if word not in set(stopwords.words('english'))]

        return self.cleaned_input, self.tokenized_input


    def predict_news(self):
        input_tfidf = self.tfidf_vectorizer.transform([self.cleaned_input])
        cluster_label = self.kmeans.predict(input_tfidf)[0]
        anomaly_score = self.isolation_forest.predict(input_tfidf)[0]

        if cluster_label == 0 and anomaly_score != -1:
            prediction = "Real"
        else:
            prediction = "Fake"

        return prediction


# Example usage

