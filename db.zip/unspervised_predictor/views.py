from django.shortcuts import render
from unspervised_predictor import model
from django.shortcuts import redirect


def homepage(request):
    return render(request, "index.html")

def redirectd(request):
    if request.method == "POST" and "get" in request.POST:
        return redirect('terms')

    return render(request, 'index.html')
def trys(request):
    data = {'result': "____"}
    if request.method == "POST" and "predict" in request.POST:
        vectorizer_path = 'unspervised_predictor/tfidf_vectorizer.pkl'
        kmeans_path = 'unspervised_predictor/kmeans.pkl'
        isolation_forest_path = 'unspervised_predictor/isolation_forest.pkl'
        text = request.POST.get('text')
        news_classifier = model.UnsupervisedNewsClassifier(vectorizer_path, kmeans_path, isolation_forest_path, text)
        prediction = news_classifier.predict_news()

        data = {'result': prediction}  # Update the value of data with the prediction

        return render(request, "terms.html", data)


    return render(request, "terms.html", data)
def terms(request):
    return render(request, "terms.html")
